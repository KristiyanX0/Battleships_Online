package constants;

public enum ShipType {
    CARRIER, BATTLESHIP, DESTROYER, SUBMARINE
}
