package constants;

public enum Direction {
    HORIZONTAL,VERTICAL
}
