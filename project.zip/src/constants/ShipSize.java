package constants;

public class ShipSize {
    public static int CARRIER = 5;
    public static int BATTLESHIP = 4;
    public static int DESTROYER = 3;
    public static int SUBMARINE = 2;
}
