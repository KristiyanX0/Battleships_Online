package game;

public enum Player {
    ME, ENEMY
}
