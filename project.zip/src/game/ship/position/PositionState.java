package game.ship.position;

public enum PositionState {
    EMPTY, DAMAGED, UNDAMAGED
}
