package command;

public record Command(String command, String[] arguments) {
}
